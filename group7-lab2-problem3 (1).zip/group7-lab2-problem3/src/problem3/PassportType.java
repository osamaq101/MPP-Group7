package problem3;

public enum PassportType {
	Regular, Official, Diplomatic
}

package problem3;

public enum Gender {
	Male, Female, Unknown
}

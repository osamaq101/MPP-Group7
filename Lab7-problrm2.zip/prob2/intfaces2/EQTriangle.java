package lesson5.lecture.intfaces2;

import java.awt.*;

public class EQTriangle implements IPolygon {

    private double side;

    public EQTriangle(double side) {
        this.side = side;
    }

    public double getSide() {
        return side;
    }

    @Override
    public double[] getLengths() {
        return new double[]{getSide(), getSide(), getSide()};
    }
}
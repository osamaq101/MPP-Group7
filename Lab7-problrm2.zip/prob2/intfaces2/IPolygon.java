package lesson5.lecture.intfaces2;

public interface IPolygon extends ClosedCurve
{
    double[] getLengths();

    @Override
    default double computePerimeter(){
        double perimeter = 0.0;

        for(double side: getLengths()){
            perimeter += side;
        }
        return perimeter;
    }
}
